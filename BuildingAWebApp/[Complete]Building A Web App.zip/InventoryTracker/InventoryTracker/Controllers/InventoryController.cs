﻿using InventoryTracker.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InventoryTracker.Controllers
{
    public class InventoryController : Controller
    {
        private readonly InventoryDbContext _context;

        public InventoryController(InventoryDbContext context)
        {
            _context = context;
        }


        // GET: Inventory
        public async Task<IActionResult> Index()
        {
            var inventoryItems = await _context.InventoryItems.ToListAsync();
            return View(inventoryItems);
        }


        // GET: Inventory/Create
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Name,Description,Quantity,Price")] InventoryItem inventoryItem)
        {
            if (ModelState.IsValid)
            {
                // Check if an item with the same name already exists
                if (_context.InventoryItems.Any(i => i.Name == inventoryItem.Name))
                {
                    ModelState.AddModelError("Name", "An item with the same name already exists.");
                    return View(inventoryItem);
                }
                LogHistory("Added", inventoryItem.Id);

                _context.Add(inventoryItem);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(inventoryItem);
        }

        // GET: Inventory/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var inventoryItem = await _context.InventoryItems.FindAsync(id);
            if (inventoryItem == null)
            {
                return NotFound();
            }
            return View(inventoryItem);
        }

        // POST: Inventory/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Description,Quantity,Price")] InventoryItem inventoryItem)
        {
            if (id != inventoryItem.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(inventoryItem);
                    await _context.SaveChangesAsync();

                    LogHistory("Updated", inventoryItem.Id);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!InventoryItemExists(inventoryItem.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(inventoryItem);
        }

        // GET: Inventory/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var inventoryItem = await _context.InventoryItems
                .FirstOrDefaultAsync(m => m.Id == id);
            if (inventoryItem == null)
            {
                return NotFound();
            }

            return View(inventoryItem);
        }

        // POST: Inventory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var inventoryItem = await _context.InventoryItems.FindAsync(id);
            _context.InventoryItems.Remove(inventoryItem);
            await _context.SaveChangesAsync();
            LogHistory("Deleted", id);
            return RedirectToAction(nameof(Index));
        }

        private bool InventoryItemExists(int id)
        {
            return _context.InventoryItems.Any(e => e.Id == id);
        }

        private void LogHistory(string changeType, int inventoryItemId)
        {
            var historyEntry = new InventoryItemHistory
            {
                InventoryItemId = inventoryItemId,
                ChangeType = changeType,
                ChangeTime = DateTime.Now,
                ChangedBy = "USER" // Assuming you're using authentication and have access to the user's name
            };

            _context.InventoryItemHistories.Add(historyEntry);
            _context.SaveChanges();
        }
    }
}
