﻿using Microsoft.AspNetCore.Mvc;

namespace InventoryTracker.Controllers
{
    public class InventoryHistoryController : Controller
    {
        private readonly InventoryDbContext _context;

        public InventoryHistoryController(InventoryDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var historyEntries = _context.InventoryItemHistories.OrderByDescending(h => h.ChangeTime).ToList();
            return View(historyEntries);
        }
    }
}
